package lld.cricbuzz.match;

public interface MatchType {
    public int noOfOvers();
    public int maxOverCountBowlers();
    public int noOfInnings();

}
