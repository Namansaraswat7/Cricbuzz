package lld.cricbuzz.enums;

public enum BallType {
    NORMAL, NOBALL, WIDEBALL
}
