package lld.cricbuzz.enums;

public enum RunType {
    ONE,TWO,THREE,FOUR,FIVE,SIX,SEVEN,ZERO
}
