package lld.cricbuzz.enums;

public enum WicketType {
    BOWLED,LBW,CATCH,CAUGHTANDBOWLED,RUNOUT
}
