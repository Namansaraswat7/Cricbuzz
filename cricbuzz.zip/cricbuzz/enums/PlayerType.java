package lld.cricbuzz.enums;

public enum PlayerType {
    BATSMAN,BOWLER,ALLROUNDER,KEEPER
}
